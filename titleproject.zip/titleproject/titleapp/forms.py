from .models import Snippet
from django import forms

class SnippetForm(forms.ModelForm):
    class Meta:
        model=Snippet
        fields=['title','snippet',]