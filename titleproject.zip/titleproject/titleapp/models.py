from django.db import models
from django.utils import timezone
class Snippet(models.Model):
    title = models.CharField(max_length=100,unique=True)
    snippet = models.CharField(max_length=250)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('title',)
        verbose_name = 'snippet'
        verbose_name_plural = 'snippets'

    def __str__(self):
        return '{}'.format(self.title)

class Tag(models.Model):
    title = models.CharField(max_length=100,unique=True)
    class Meta:
        ordering = ('title',)
        verbose_name = 'title'
        verbose_name_plural = 'titles'

    def __str__(self):
        return '{}'.format(self.title)