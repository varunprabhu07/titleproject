from . import views
from django.urls import path

urlpatterns = [
    path('',views.demo,name='demo'),
    path('add',views.add,name='add'),
    path('delete/<int:snippetid>/',views.delete,name='delete'),
    path('update/<int:id>/',views.update,name='update'),
    path('cbvhome/',views.SnippetListView.as_view(),name='cbvhome'),
    path('cbvdetail/<int:pk>/',views.SnippetDetailView.as_view(),name='cbvdetail'),
    path('cbvupdate/<int:pk>/',views.SnippetUpdateView.as_view(),name='cbvupdate'),
    path('cbvdelete/<int:pk>/',views.SnippetDeleteView.as_view(),name='cbvdelete'),
]