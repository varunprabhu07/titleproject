from django.shortcuts import render
from django.shortcuts import render, redirect
from django.urls import reverse_lazy

from .forms import SnippetForm
from .models import Snippet
from django.views.generic import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import UpdateView,DeleteView



def demo(request):
    return render(request,'index.html')



class SnippetDeleteView(DeleteView):
    model = Snippet
    template_name = 'delete.html'
    success_url = reverse_lazy('cbvhome')

class SnippetUpdateView(UpdateView):
    model = Snippet
    template_name = 'update.html'
    context_object_name = 'snippet'
    fields = ('title','snippet','timestamp')

    def get_success_url(self):
        return reverse_lazy('cbvdetail',kwargs={'pk':self.object.id})

class SnippetListView(ListView):
    model = Snippet
    template_name = 'home.html'
    context_object_name = 'snippet1'

class SnippetDetailView(DetailView):
    model = Snippet
    template_name = 'detail.html'
    context_object_name = 'snippet'


def add(request):
    snippet1=Snippet.objects.all()
    if request.method == 'POST':
        title=request.POST.get('title','')
        snippet=request.POST.get('snippet','')
        snippet=Snippet(title=title,snippet=snippet)
        snippet.save()
    return render(request,'home.html',{'snippet1':snippet1})

def delete(request,snippetid):
    snippet=Snippet.objects.get(id=snippetid)
    if request.method == 'POST':
        snippet.delete()
        return redirect('/add')
    return render(request,'delete.html')

def update(request,id):
    snippet=Snippet.objects.get(id=id)
    f=SnippetForm(request.POST or None,instance=snippet)
    if f.is_valid():
        f.save()
        return redirect('/add')
    return render(request,'edit.html',{'f':f,'snippet':snippet})